uniquifyNetlist -top gcd gcd_uniquify.v gcd_SYN.v
rm -f encounter.*
